<?php
/**
 * Archivo: get_cash_incomes.php
 * Descripción: Retorna la lista de ingresos activos (polarity = 1) de una caja específica junto con el total acumulado y la utilidad.
 * Proyecto: COBAN365
 * Desarrollador: Mauricio Chara
 * Versión: 1.3.0
 * Fecha de actualización: 27-May-2025
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once "../../db.php";

if (!isset($_GET["id_cash"])) {
    echo json_encode([
        "success" => false,
        "message" => "Falta el parámetro obligatorio id_cash."
    ]);
    exit();
}

$id_cash = intval($_GET["id_cash"]);

try {
    // Obtener ingresos individuales, incluyendo transferencias aceptadas con impacto (neutral = 0) hacia esta caja
    $sql = "
        SELECT 
            t.*,
            tt.name AS transaction_type_name,
            c.name AS correspondent_name,
            u.fullname AS cashier_name
        FROM transactions t
        LEFT JOIN transaction_types tt ON t.transaction_type_id = tt.id
        LEFT JOIN correspondents c ON t.id_correspondent = c.id
        LEFT JOIN users u ON t.id_cashier = u.id
        WHERE t.state = 1 AND (
            (t.polarity = 1 AND t.id_cash = :id_cash AND t.is_transfer = 0)
            OR
            (t.is_transfer = 1 AND t.neutral = 0 AND t.transfer_status = 1 AND t.box_reference = :id_cash)
        )
        ORDER BY t.created_at DESC
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id_cash", $id_cash, PDO::PARAM_INT);
    $stmt->execute();
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    setlocale(LC_TIME, 'es_ES.UTF-8');
    foreach ($transactions as &$tx) {
        $datetime = new DateTime($tx["created_at"]);
        $tx["formatted_date"] = $datetime->format("d") . " de " .
            strftime("%B", $datetime->getTimestamp()) . " de " .
            $datetime->format("Y") . " a las " .
            $datetime->format("h:i A");
        $tx["utility"] = isset($tx["utility"]) ? floatval($tx["utility"]) : 0;
    }

    // Calcular total de ingresos y utilidad
    $sumSql = "
        SELECT 
            SUM(cost) AS total_income,
            SUM(utility) AS total_utility
        FROM transactions
        WHERE state = 1 AND (
            (polarity = 1 AND id_cash = :id_cash AND is_transfer = 0)
            OR
            (is_transfer = 1 AND neutral = 0 AND transfer_status = 1 AND box_reference = :id_cash)
        )
    ";
    $sumStmt = $pdo->prepare($sumSql);
    $sumStmt->bindParam(":id_cash", $id_cash, PDO::PARAM_INT);
    $sumStmt->execute();
    $sumResult = $sumStmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "total" => floatval($sumResult["total_income"] ?? 0),
        "utility" => floatval($sumResult["total_utility"] ?? 0),
        "data" => $transactions
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "success" => false,
        "message" => "Error al obtener los ingresos: " . $e->getMessage()
    ]);
}
?>